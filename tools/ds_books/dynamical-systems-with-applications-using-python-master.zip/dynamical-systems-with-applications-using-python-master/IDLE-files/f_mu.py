# The logistic function - save file as f_mu.py.
# Run the Module (or type F5).
"""
You can write your own text here.
Created on Mon Mar 12 09:23:47 2018
@author: sladmin
"""
def f_mu(mu, x):
    return mu * x * (1 - x)
