We're interested in understanding when zero shot capabilities appear.
