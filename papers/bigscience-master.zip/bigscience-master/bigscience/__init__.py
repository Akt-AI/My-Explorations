"""Top-level package for Big Science."""

__author__ = """Stas Bekman"""
__email__ = 'stas@huggingface.co'
__version__ = '0.1.0'
