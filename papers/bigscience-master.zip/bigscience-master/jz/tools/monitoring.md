# Monitoring

## nvtop

A nice alternative to `watch -n1 nvidia-smi`

```
module load nvtop
nvtop
```
