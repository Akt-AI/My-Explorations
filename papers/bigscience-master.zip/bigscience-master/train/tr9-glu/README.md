Experiment 9: GLU activations
