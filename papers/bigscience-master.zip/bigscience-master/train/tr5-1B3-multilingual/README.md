`generate_dataset_probabilities.py` is deprecated; the new way to generate probabilities is at `/data/sampling_probs/calc_iterator_prob.py`.
